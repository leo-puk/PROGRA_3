/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.dominios;

/**
 *
 * @author CRISTHIAN
 */
public class VisitanteDTO {

    /**
     * @return the direccionIp
     */
    public Integer getDireccionIp() {
        return direccionIp;
    }

    /**
     * @param direccionIp the direccionIp to set
     */
    public void setDireccionIp(Integer direccionIp) {
        this.direccionIp = direccionIp;
    }
    private Integer direccionIp; 
    private static Integer visitas;
    
}
