package com.pucp.modelo;

public enum TIPO_ALUMNO {
    PREUNI,PREGRADO,POSTGRADO
}
