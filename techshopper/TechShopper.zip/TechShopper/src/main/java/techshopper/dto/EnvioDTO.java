/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package techshopper.dto;

import java.time.LocalDateTime;

/**
 *
 * @author CRISTHIAN
 */
public class EnvioDTO {

    /**
     * @return the idEnvio
     */
    public Integer getIdEnvio() {
        return idEnvio;
    }

    /**
     * @param idEnvio the idEnvio to set
     */
    public void setIdEnvio(Integer idEnvio) {
        this.idEnvio = idEnvio;
    }

    /**
     * @return the destino
     */
    public LocalizacionDTO getDestino() {
        return destino;
    }

    /**
     * @param destino the destino to set
     */
    public void setDestino(LocalizacionDTO destino) {
        this.destino = destino;
    }

    /**
     * @return the fechaEntrega
     */
    public LocalDateTime getFechaEntrega() {
        return fechaEntrega;
    }

    /**
     * @param fechaEntrega the fechaEntrega to set
     */
    public void setFechaEntrega(LocalDateTime fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    /**
     * @return the empresaCourier
     */
    public String getEmpresaCourier() {
        return empresaCourier;
    }

    /**
     * @param empresaCourier the empresaCourier to set
     */
    public void setEmpresaCourier(String empresaCourier) {
        this.empresaCourier = empresaCourier;
    }

    /**
     * @return the precio
     */
    public Double getPrecio() {
        return precio;
    }

    /**
     * @param precio the precio to set
     */
    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    
    
    
    private Integer idEnvio;
    private LocalizacionDTO destino;
    private LocalDateTime fechaEntrega;
    private String empresaCourier;
    private Double precio;
    
    
}
